package www.mabnets.afyahalisi;

import java.io.Serializable;

public class portal implements Serializable {
    public String id;
    public String category;
    public String total;

}
