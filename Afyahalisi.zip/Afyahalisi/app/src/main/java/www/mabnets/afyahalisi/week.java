package www.mabnets.afyahalisi;
import  java.io.Serializable;
public class week implements Serializable{
    public String id;
    public String week;
    public String message;
    public String status;
    public String time;

}
