package www.mabnets.afyahalisi;
import java.io.Serializable;
public class materialz implements Serializable{

    public String id;
    public String category;
    public String title;
    public String document;
    public String mesage;
    public String time;

}
