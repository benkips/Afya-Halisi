package www.mabnets.afyahalisi;

import java.io.Serializable;

public class news implements Serializable {
    public String id;
    public String sender;
    public String tittle;
    public String message;
}
