package www.mabnets.afyahalisi;

import java.io.Serializable;

public class chatz implements Serializable {
    public String id;
    public String category;
    public String sender;
    public String message;
    public String time;
    public String replies;
}
