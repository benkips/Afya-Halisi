package www.mabnets.afyahalisi;

import java.io.Serializable;

public class maxxxx implements Serializable {
    public String maxn;
    public  String total;
}
