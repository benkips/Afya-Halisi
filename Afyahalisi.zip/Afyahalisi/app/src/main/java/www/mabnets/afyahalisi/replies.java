package www.mabnets.afyahalisi;

import java.io.Serializable;

public class replies implements Serializable {
    public  String id;
    public  String chatid;
    public  String sender;
    public  String chat;
    public  String time;
}
