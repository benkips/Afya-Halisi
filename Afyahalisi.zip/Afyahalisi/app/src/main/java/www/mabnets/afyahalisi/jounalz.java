package www.mabnets.afyahalisi;

import java.io.Serializable;

public class jounalz implements Serializable {
    public String id;
    public String title;
    public String url;

}
